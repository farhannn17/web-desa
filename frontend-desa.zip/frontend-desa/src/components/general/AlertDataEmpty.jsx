import React from "react";

export default function AlertDataEmpty() {
  return (
    <div className="alert alert-danger rounded-3">Data Belum Tersedia!</div>
  );
}
